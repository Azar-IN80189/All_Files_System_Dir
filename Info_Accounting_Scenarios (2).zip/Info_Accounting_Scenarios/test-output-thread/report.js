$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "522d8008-ad45-4d32-b186-c2b03198ef3f",
    "feature": "Info-Accouting Tax Rate scenario",
    "scenario": "Tax Rate scenario",
    "start": 1663685278160,
    "group": 1,
    "content": "",
    "tags": "@taxrate,@loginfunction,",
    "end": 1663685332673,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});