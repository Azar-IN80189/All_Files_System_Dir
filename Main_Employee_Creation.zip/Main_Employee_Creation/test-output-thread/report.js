$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "3e6f000f-9ee5-4125-9949-741d66b638dd",
    "feature": "Employee Basic Details",
    "scenario": "Employee Creation",
    "start": 1641227744680,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1641227916706,
    "className": "failed"
  },
  {
    "id": "a44d090b-74f9-4d2b-a466-6151df67ad66",
    "feature": "Employee Basic Details",
    "scenario": "Employee Creation",
    "start": 1641227572188,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1641227744680,
    "className": "failed"
  },
  {
    "id": "eba771ee-c65b-46cf-9fe7-d2b061397480",
    "feature": "Employee Basic Details",
    "scenario": "Employee Creation",
    "start": 1641227916706,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1641228089077,
    "className": "failed"
  },
  {
    "id": "f9564c9a-9dfe-4418-af0b-1db3f1c24705",
    "feature": "Employee Basic Details",
    "scenario": "Employee Creation",
    "start": 1641227131316,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1641227277817,
    "className": "passed"
  },
  {
    "id": "f2d2349b-b895-44c3-84a0-cd995f23e6ac",
    "feature": "Employee Basic Details",
    "scenario": "Employee Creation",
    "start": 1641227277817,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1641227398327,
    "className": "failed"
  },
  {
    "id": "66e52603-2cdb-4a44-b13d-add2b7f7d0ab",
    "feature": "Employee Basic Details",
    "scenario": "Employee Creation",
    "start": 1641227398380,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1641227572180,
    "className": "failed"
  },
  {
    "id": "0b87d947-f0c3-4fc5-8359-7189252275f1",
    "feature": "Employee Basic Details",
    "scenario": "Employee Creation",
    "start": 1641228089077,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1641228261587,
    "className": "failed"
  },
  {
    "id": "c96ffaff-9ca0-4f43-b84b-52c721f9256c",
    "feature": "Employee Basic Details",
    "scenario": "Employee Creation",
    "start": 1641228261587,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1641228434799,
    "className": "failed"
  },
  {
    "id": "dc0772f6-7da1-4d5e-9914-6ee79c9695c3",
    "feature": "Employee Basic Details",
    "scenario": "Employee Creation",
    "start": 1641228434799,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1641228575357,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});