$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "97492b8d-41f1-420b-aa36-0f417fd77566",
    "feature": "Info-Accouting Tax Rate scenario",
    "scenario": "Currencies scenario",
    "start": 1662702584463,
    "group": 1,
    "content": "",
    "tags": "@currencies,@loginfunction,",
    "end": 1662702620990,
    "className": "passed"
  },
  {
    "id": "f0bbbed9-ee94-4580-845c-94cb66fd8c3e",
    "feature": "Info-Accouting Tax Rate scenario",
    "scenario": "Tax Rate scenario",
    "start": 1662702541779,
    "group": 1,
    "content": "",
    "tags": "@taxrate,@loginfunction,",
    "end": 1662702584457,
    "className": "passed"
  },
  {
    "id": "6663ff8c-916f-45b9-ac50-091bfcce386b",
    "feature": "Info-Accouting Inventory-Items",
    "scenario": "Inventory-Items scenario",
    "start": 1662702620995,
    "group": 1,
    "content": "",
    "tags": "@inventoryitems,@loginfunction,",
    "end": 1662702670321,
    "className": "passed"
  },
  {
    "id": "7e7d03e4-7d82-4508-a83d-c749e4073691",
    "feature": "Info-Accouting Sales-Invoice scenario",
    "scenario": "Sales-Invoice scenario",
    "start": 1662702813093,
    "group": 1,
    "content": "",
    "tags": "@invoice,@loginfunction,",
    "end": 1662702870956,
    "className": "passed"
  },
  {
    "id": "53b91103-745e-4cef-ba73-39cace2a6e98",
    "feature": "Info-Accouting Inventory-PriceList scenario",
    "scenario": "Inventory-PriceList scenario",
    "start": 1662702670326,
    "group": 1,
    "content": "",
    "tags": "@pricelist,@loginfunction,",
    "end": 1662702714382,
    "className": "passed"
  },
  {
    "id": "d5ae50d6-ce85-4582-ae26-970079637650",
    "feature": "Info-Accouting Sales-Delivery order scenario",
    "scenario": "Sales-Delivery order scenario",
    "start": 1662702950373,
    "group": 1,
    "content": "",
    "tags": "@deliveryorder,@loginfunction,",
    "end": 1662703035272,
    "className": "passed"
  },
  {
    "id": "dcdb8d87-fadf-492b-9164-1bb9ac43b708",
    "feature": "Info-Accouting forgot password",
    "scenario": "Forgot password scenario",
    "start": 1662702485566,
    "group": 1,
    "content": "",
    "tags": "@forgotpassword,@loginmain,",
    "end": 1662702541772,
    "className": "passed"
  },
  {
    "id": "5c0faaa3-e6d4-4d12-9525-0e1ec15191ab",
    "feature": "Info-Accouting Sales-Quotation scenario",
    "scenario": "Sales-Quotation scenario",
    "start": 1662702714385,
    "group": 1,
    "content": "",
    "tags": "@quotation,@loginfunction,",
    "end": 1662702813089,
    "className": "passed"
  },
  {
    "id": "dd8adc15-2fd3-4f9c-bd5d-a2fe0b9a3a52",
    "feature": "Info-Accouting Sales-Credit Note scenario",
    "scenario": "Sales-Credit Note scenario",
    "start": 1662702870961,
    "group": 1,
    "content": "",
    "tags": "@creditnotes,@loginfunction,",
    "end": 1662702950369,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});