$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "1ddfa424-4003-45ff-b0ec-efcca5417ede",
    "feature": "Update profile information",
    "scenario": "Update user information details",
    "start": 1663749978897,
    "group": 1,
    "content": "",
    "tags": "@profile,",
    "end": 1663750007179,
    "className": "passed"
  },
  {
    "id": "8cbe301c-0848-4480-9fd1-8c5e1a5794d3",
    "feature": "Info-Accouting Tax Rate scenario",
    "scenario": "Currencies scenario",
    "start": 1663750072354,
    "group": 1,
    "content": "",
    "tags": "@currencies,",
    "end": 1663750090587,
    "className": "passed"
  },
  {
    "id": "80017875-d3a2-4aa8-80ea-381a0a6b95d4",
    "feature": "Login Feature",
    "scenario": "Get login infoaccounting App",
    "start": 1663749969272,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1663749978887,
    "className": "passed"
  },
  {
    "id": "a7ec455c-d06d-4276-9320-631d139c1a22",
    "feature": "Info-Accouting Tax Rate scenario",
    "scenario": "Tax Rate scenario",
    "start": 1663750041873,
    "group": 1,
    "content": "",
    "tags": "@taxrate,",
    "end": 1663750072350,
    "className": "passed"
  },
  {
    "id": "d8919d5a-0bee-4be5-84a7-355ff2038047",
    "feature": "Organaization feature",
    "scenario": "Details organaization",
    "start": 1663750007182,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1663750041867,
    "className": "passed"
  },
  {
    "id": "97d915f4-4ae3-4443-be33-45202e91e5fe",
    "feature": "Info-Accouting forgot password",
    "scenario": "Forgot password scenario",
    "start": 1663750090589,
    "group": 1,
    "content": "",
    "tags": "@forgotpassword,",
    "end": 1663750140520,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});