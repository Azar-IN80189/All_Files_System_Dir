$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "04a10163-9aed-45b1-ba89-e20e1d5d875e",
    "feature": "Info-Accouting forgot password",
    "scenario": "Forgot password scenario",
    "start": 1662013658472,
    "group": 1,
    "content": "",
    "tags": "@forgotpassword,@loginmain,",
    "end": 1662013707156,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});